import java.io.*;
import java.nio.charset.StandardCharsets;

public class ProcesoC { //Contador de vocales
    private static int contarVocales(String s) {
        int v = 0;
        for (char c : s.toCharArray()) {
            switch (c) {
                case 'a': case 'e': case 'i': case 'o': case 'u':
                    v++; break;
            }
        }
        return v;
    }

    public static void main(String[] args) {
        int totalVocales = 0;

        try (
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
            PrintWriter out = new PrintWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8), true)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                int idx = line.lastIndexOf(',');
                if (idx < 0) continue; // línea mal formada
                String cadena = line.substring(0, idx);
                String lenStr = line.substring(idx + 1).trim();
                int len;
                try { len = Integer.parseInt(lenStr); }
                catch (NumberFormatException e) { len = cadena.length(); }

                int v = contarVocales(cadena);
                totalVocales += v;
                out.printf("Cadena: \"%s\" | Caracteres: %d | Vocales: %d%n", cadena, len, v);
            }
            out.println("TOTAL_VOCALES=" + totalVocales);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
