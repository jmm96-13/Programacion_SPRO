import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class ProcesoD { // gestor de procesos A, B y C con tuberías

    // Copia bytes de 'in' a 'out' hasta EOF. Cierra 'out' al terminar.
    private static Thread pump(InputStream in, OutputStream out) {
        Thread t = new Thread(() -> {
            try (in; out) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    out.flush();
                }
            } catch (IOException ignored) {}
        });
        t.setDaemon(true);
        t.start();
        return t;
    }

    // Consume un stream línea a línea y lo muestra con prefijo.
    private static Thread consumeWithPrefix(InputStream in, String prefix, boolean toErr) {
        Thread t = new Thread(() -> {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String msg = prefix + line;
                    if (toErr) System.err.println(msg);
                    else System.out.println(msg);
                }
            } catch (IOException ignored) {}
        });
        t.setDaemon(true);
        t.start();
        return t;
    }

    private static String[] cmd(String s) { return s.split(" "); } // requisito split(" ")

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Uso: java ProcesoD <N> (1 <= N < 10)");
            System.exit(1);
        }
        int n;
        try { n = Integer.parseInt(args[0]); }
        catch (NumberFormatException e) {
            System.err.println("El argumento debe ser entero.");
            return;
        }
        if (n <= 0 || n >= 10) {
            System.err.println("El argumento debe ser positivo y menor que 10.");
            return;
        }

        // Muestra tu nombre para la captura, si quieres:
        // System.out.println("Alumno: TU NOMBRE COMPLETO");

        Runtime rt = Runtime.getRuntime();
        List<Process> procesos = new ArrayList<>();
        List<Thread> hilos = new ArrayList<>();

        for (int i = 1; i <= n; i++) {
            final int id = i;

            // Ejecuta los JARs en el directorio actual
            Process pA = rt.exec(cmd("java -jar ProcesoA.jar"));
            Process pB = rt.exec(cmd("java -jar ProcesoB.jar"));
            Process pC = rt.exec(cmd("java -jar ProcesoC.jar"));

            procesos.add(pA); procesos.add(pB); procesos.add(pC);

            // Conexión de tuberías: A.stdout -> B.stdin -> C.stdin
            hilos.add(pump(pA.getInputStream(), pB.getOutputStream()));
            hilos.add(pump(pB.getInputStream(), pC.getOutputStream()));

            // Mostrar salida de C y errores con prefijos
            hilos.add(consumeWithPrefix(pC.getInputStream(), "[P" + id + "] ", false));
            hilos.add(consumeWithPrefix(pA.getErrorStream(), "[P" + id + "][A-ERR] ", true));
            hilos.add(consumeWithPrefix(pB.getErrorStream(), "[P" + id + "][B-ERR] ", true));
            hilos.add(consumeWithPrefix(pC.getErrorStream(), "[P" + id + "][C-ERR] ", true));
        }

        // Esperar a que terminen
        for (Process p : procesos) p.waitFor();
        for (Thread t : hilos) t.join(100); // vacía buffers
    }
}
